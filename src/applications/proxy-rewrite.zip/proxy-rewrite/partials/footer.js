export default `
  <footer class="footer" role="contentinfo">
    <div id="footerNav" class="merger"></div>
  </footer>
`;
